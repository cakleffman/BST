public class BST {
    
    private Node root;
    
    private class Node {
        private int data;
        private Node left;
        private Node right;
        
        private Node(int data) {
            this.data = data;
            this.left = null;
            this.right = null;
        }
        
        private Node(int data, Node left, Node right) {
            this.data = data;
            this.left = left;
            this.right = right;
        }
    }
    
    public BST() {
        this.root = null;
    }
    
    public BST(int[] a) {
        for (int i = 0; i < a.length; i++) {
            add(a[i]);
        }
    }
    
    public void add(int x) {
        if (root == null) {
            root = new Node(x);
        } else {
            Node finder = root;
            boolean addedNode = false;
            while (!addedNode) {
                if (x <= finder.data) {
                    if (finder.left == null) {
                        finder.left = new Node(x);
                        addedNode = true;
                    } else {
                        finder = finder.left;
                    }
                } else {
                    if (finder.right == null) {
                        finder.right = new Node(x);
                        addedNode = true;
                    } else {
                        finder = finder.right;
                    }
                }
            }
        }
    }
    
    public String toString() {
        return toStringHelper(root, 0);
    }
    
    public String toStringHelper(Node n, int depth) {
        String ret = "";
        if (n == null) {
            return ret;
        }
        
        ret += toStringHelper(n.right, depth + 1);

        String tabs = "";
        for (int i = 0; i < depth; i++) {
            tabs += "\t";
        }
        ret += tabs + n.data + "\n";

        ret += toStringHelper(n.left, depth + 1);
        
        return ret;
    }
    
    // YOU DO NOT NEED TO MODIFY ANYTHING ABOVE THIS LINE
    
    // You need to write this method. I'm just returning -1 so the code compiles.
    public int nearest(int x) {
        Node current = root;
        int distance = Math.abs(current.data - x);
        int closestNode = current.data;
        if(current.left == null && current.right == null){
            return current.data;
        }
        while(current != null){
            
            if(Math.abs(current.data - x) < distance){
                distance = Math.abs(current.data - x);
                closestNode = current.data; 
            }
            
            if(x <= current.data){
                current = current.left;
            }
            else if(x > current.data){
                current = current.right; 
            }
        }
        return closestNode;
    }
    
    // You need to write this method.
    public void removeRoot() {
        Node current = root;
        if(current.left == null){
            root.data = current.right.data;
            root.right = current.right.right;
        }
        else if(current.left != null && current.left.right == null){
            root.data = current.left.data;
            root.left = current.left.left;
        }
        else if(current.left != null && current.left.right != null){
            current = current.left;
            while(current.right.right != null){
                current = current.right;
            }
            root.data = current.right.data;
            current.right = null;
            
           
        }
    }
    
    public static void main(String[] args) {
        
        // Here's one BST, you can (and should!) create others to test your methods.
        int[] nums = {20, 10, 11, 12, 13, 14, 18, 14};
       
        BST bst = new BST(nums);
        System.out.println(bst);
        System.out.println(bst.nearest(25));
        bst.removeRoot();
        System.out.println(bst);
        
    }
}